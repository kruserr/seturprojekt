# Growbox

# List of equipment:

- Raspberry Pi 4 (NVD R4B1-14)

- PSU (NVD PSU4-06)

- Water Level sensor
- Temperature Sensor (digital)
- Humidity Sensor
- Relay


# Notes:
- When relay opens temp/humid sensor reads error perhaps from noise
